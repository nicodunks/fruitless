# Static anatomical audit of the failed full-network pilot

Read-only audit of the same full graph, its annotations, and seed-1 spike recordings. No simulations or frontend changes. `audit.json` contains exact body IDs for every input/readout group, top direct neighbors, ranked two-hop intermediates, and activity-path summaries; `audit.py` builds connectivity tables. Counts are anatomical synapse counts, not effective conductances.

## What explains the silent intended circuit

The two candidate foreleg sensory cohorts have no direct edges to mAL or P1-related cells. Male-candidate LgLG6/7 has only 37 synapse counts into the two PPN1 cells; female-candidate LgLG5/8 has 20. PPN1 itself has 33 counts into mAL and only one count into the entire P1-related cohort. Thus a literature annotation alone does not make PPN1 a strong direct positive control in this reconstruction.

The largest short paths from either sensory group to mAL/P1 traverse AN09B017 ascending neurons. All are consensus glutamate, modeled inhibitory in the pilot. Specific annotated vAB3 instances are AN09B017e (13341, 13693), AN09B017f (11998, 512498), and AN09B017g (14320, 922722). Candidate-female input supplies 836+886 counts to the g pair; that pair supplies 4,151 counts to mAL and 425 to P1-related cells. This is strong anatomical access but not proof of excitation. Flipping signs merely to obtain a result is not warranted; receptor-specific literature could justify a separate transparent sensitivity hypothesis.

The conservative female trial's only active neurons have nonpositive assumed signs: there is no active excitatory path into either readout. Male stimulation does recruit 189 excitatory neurons, but their total outgoing counts into the entire mAL and P1-related cohorts are only 134 and 156 respectively. PPN1 stimulation recruits 1,249 excitatory neurons with 1,106/1,243 counts into mAL/P1-related; sparse counts alone do not guarantee threshold crossing or net excitation under recurrent inhibition.

## Narrow defensible next control

The actual mAL-to-P1-related pathway is strong: 1,106 neuron-pair connections, 8,076 synapse counts. Reverse P1-related-to-mAL connectivity is 1,069 pairs and 8,212 counts. A direct artificial excitation-plus-mAL-output-block test can verify a functional inhibitory brake in the full model. It cannot demonstrate sex preference, nor natural sensory recruitment.

A purely anatomical upstream positive control is the strongest cholinergic P1 input type, SMP550: body IDs 11470 and 13244, with 552 and 537 counts into P1-related cells. They have no courtship-specific synonyms in this annotation; selecting them tests generic excitatory access, not male/female cues. If selected after inspection, label this exploratory and use fixed stimulation and seeds across intervention conditions.

Do not use the existing huge externally injected suprathreshold voltage impulses directly on P1 as evidence of recruitment: they can force spikes regardless of inhibitory synapses. Subthreshold current drive or actual upstream stimulation is a more interpretable model check. Full physiology and target choice remain unvalidated.
