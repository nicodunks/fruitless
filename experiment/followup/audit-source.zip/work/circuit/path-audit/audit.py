import json
from pathlib import Path
import numpy as np
import pyarrow.feather as f
from scipy.sparse import load_npz
r=Path('work/circuit'); W=load_npz(r/'full-graph.npz'); z=np.load(r/'full-nodes.npz');ids=z['ids']; signs=z['signs']; meta=json.loads((r/'full-meta.json').read_text()); groups=meta['groups']
ann={x['bodyId']:x for x in f.read_table(r/'annotations.feather').to_pylist()}; nts={x['body']:x['consensus_nt'] for x in f.read_table(r/'nt.feather',columns=['body','consensus_nt']).to_pylist()}
def desc(i):
 a=ann[int(ids[i])]; return {k:a.get(k) for k in ['bodyId','type','instance','synonyms','fruDsx','receptorType','entryNerve']}|{'nt':nts.get(int(ids[i]))}
out={'direct':{},'top_input_neighbors':{},'top_readout_inputs':{},'two_hop':{}}
for a,ai in groups.items():
 for b,bi in groups.items():
  v=W[ai][:,bi];out['direct'][a+' -> '+b]={'edges':v.nnz,'synapses':int(v.sum())}
for a in ['candidate_male','candidate_female','PPN1','mAL']:
 ai=groups[a]; score=np.asarray(W[ai].sum(axis=0)).ravel();top=np.argsort(score)[-30:][::-1]
 out['top_input_neighbors'][a]=[desc(int(j))|{'input_synapses':int(score[j])} for j in top]
 for b in ['PPN1','mAL','P1_related']:
  target=np.asarray(W[:,groups[b]].sum(axis=1)).ravel(); product=score*target; top=np.argsort(product)[-30:][::-1]
  out['two_hop'][a+' -> '+b]=[desc(int(j))|{'input_synapses':int(score[j]),'output_synapses':int(target[j]),'product':int(product[j])} for j in top if product[j]>0]
for b in ['mAL','P1_related']:
 score=np.asarray(W[:,groups[b]].sum(axis=1)).ravel();top=np.argsort(score)[-40:][::-1];out['top_readout_inputs'][b]=[desc(int(j))|{'synapses':int(score[j])} for j in top]
(r/'path-audit/audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out['direct'],indent=2))
for k,v in out['two_hop'].items(): print(k,[(x['bodyId'],x['type'],x['nt'],x['input_synapses'],x['output_synapses']) for x in v[:8]])
print('Top P1 inputs',[(x['bodyId'],x['type'],x['nt'],x['synapses']) for x in out['top_readout_inputs']['P1_related'][:20]])
