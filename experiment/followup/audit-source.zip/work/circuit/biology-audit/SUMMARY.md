# Controlled route experiment

All neurons and synapse-count weights remain as in the full-network experiment. Only stated sign assumptions and mAL output-transmission block differ. Discovery seeds1–3 and fixed holdout11–13. No movement decoder.

| Stage | Sign setting | Input | Seed | Events each | Eight-cell spikes intact→blocked | Broad49 spikes intact→blocked | mAL spikes intact→blocked |
|---|---|---|---:|---:|---:|---:|---:|
| discovery | conservative | candidate_female | 1 | 1161 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | candidate_female | 2 | 1106 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | candidate_female | 3 | 1116 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | candidate_male | 1 | 1151 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | candidate_male | 2 | 1133 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | candidate_male | 3 | 1035 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | vAB3 | 1 | 124 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | vAB3 | 2 | 125 | 0→0 | 0→0 | 0→0 |
| discovery | conservative | vAB3 | 3 | 93 | 0→0 | 0→0 | 0→0 |
| discovery | vAB3_and_female_input_excitatory | candidate_female | 1 | 1161 | 15→30 | 51→68 | 56→69 |
| discovery | vAB3_and_female_input_excitatory | candidate_female | 2 | 1106 | 18→24 | 52→66 | 55→57 |
| discovery | vAB3_and_female_input_excitatory | candidate_female | 3 | 1116 | 17→28 | 51→68 | 57→70 |
| discovery | vAB3_excitatory | candidate_female | 1 | 1161 | 0→0 | 0→0 | 0→0 |
| discovery | vAB3_excitatory | candidate_female | 2 | 1106 | 0→0 | 0→0 | 0→0 |
| discovery | vAB3_excitatory | candidate_female | 3 | 1116 | 0→0 | 0→0 | 0→0 |
| discovery | vAB3_excitatory | candidate_male | 1 | 1151 | 0→7 | 48→67 | 114→148 |
| discovery | vAB3_excitatory | candidate_male | 2 | 1133 | 0→9 | 48→53 | 112→162 |
| discovery | vAB3_excitatory | candidate_male | 3 | 1035 | 0→2 | 44→56 | 116→138 |
| discovery | vAB3_excitatory | vAB3 | 1 | 124 | 0→20 | 22→86 | 352→438 |
| discovery | vAB3_excitatory | vAB3 | 2 | 125 | 0→21 | 23→82 | 369→462 |
| discovery | vAB3_excitatory | vAB3 | 3 | 93 | 0→18 | 19→65 | 264→332 |
| holdout | vAB3_and_female_input_excitatory | candidate_female | 11 | 1088 | 15→28 | 51→60 | 56→66 |
| holdout | vAB3_and_female_input_excitatory | candidate_female | 12 | 1061 | 15→26 | 48→66 | 61→66 |
| holdout | vAB3_and_female_input_excitatory | candidate_female | 13 | 1111 | 13→25 | 49→63 | 52→60 |
| holdout | vAB3_excitatory | candidate_male | 11 | 1124 | 0→5 | 53→66 | 101→147 |
| holdout | vAB3_excitatory | candidate_male | 12 | 1073 | 0→5 | 49→70 | 108→138 |
| holdout | vAB3_excitatory | candidate_male | 13 | 1060 | 0→3 | 44→57 | 97→120 |
| holdout | vAB3_excitatory | vAB3 | 11 | 108 | 0→16 | 6→51 | 315→466 |
| holdout | vAB3_excitatory | vAB3 | 12 | 112 | 0→19 | 18→73 | 329→414 |
| holdout | vAB3_excitatory | vAB3 | 13 | 118 | 0→19 | 16→76 | 346→454 |

All paired inputs match. Three restoration runs exactly reproduce every saved array from discovery intactseed1.

Read EVIDENCE.md for subtype-mapping caveat, the literature basis and scope of sign assumptions, and why a spike response is not behavioral preference.
