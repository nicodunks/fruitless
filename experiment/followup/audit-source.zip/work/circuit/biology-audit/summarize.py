import json,numpy as np
from pathlib import Path
p=Path(__file__).parent
x=json.loads((p/'results.json').read_text())['results'];h=json.loads((p/'holdout-results.json').read_text())['results'];allrows=x+h;rows=[];checks=[]
for stage,source in [('discovery',x),('holdout',h)]:
 for setting,pop,seed in sorted(set((r['setting'],r['input'],r['seed']) for r in source)):
  pair=[r for r in source if (r['setting'],r['input'],r['seed'])==(setting,pop,seed)]
  if len(pair)!=2:continue
  a=next(r for r in pair if r['condition']=='intact');b=next(r for r in pair if r['condition']=='mAL_blocked')
  assert a['events']==b['events']
  row={'stage':stage,'setting':setting,'input':pop,'seed':seed,'input_events_each':a['events']}
  for popname,col in [('R71G01_related','P1_8'),('P1_related','P1_49'),('mAL','mAL')]:
   aa=a['readouts'][popname];bb=b['readouts'][popname]
   row[col+'_intact']=aa['spikes'];row[col+'_blocked']=bb['spikes'];row[col+'_delta']=bb['spikes']-aa['spikes'];row[col+'_mean_voltage_delta_mV']=bb['mean_voltage_deviation_mV']-aa['mean_voltage_deviation_mV']
  rows.append(row)
for r in h:
 if r['condition']!='restored':continue
 orig=next(q for q in x if (q['setting'],q['input'],q['seed'],q['condition'])==(r['setting'],r['input'],1,'intact'))
 a=np.load(p/(orig['key']+'.npz'));b=np.load(p/(r['key']+'.npz'));assert a.files==b.files
 match=all(np.array_equal(a[k],b[k]) for k in a.files);assert match
 checks.append({'setting':r['setting'],'input':r['input'],'seed':1,'restoration_all_recorded_arrays_exact':match})
(p/'summary.json').write_text(json.dumps({'comparisons':rows,'checks':checks,'total_runs':len(allrows),'conclusion':'Repeated modeled response disinhibition under literature-informed signs, not mate-preference reversal.'},indent=2))
lines=['# Controlled route experiment','', 'All neurons and synapse-count weights remain as in the full-network experiment. Only stated sign assumptions and mAL output-transmission block differ. Discovery seeds1–3 and fixed holdout11–13. No movement decoder.','', '| Stage | Sign setting | Input | Seed | Events each | Eight-cell spikes intact→blocked | Broad49 spikes intact→blocked | mAL spikes intact→blocked |','|---|---|---|---:|---:|---:|---:|---:|']
for r in rows:lines.append(f"| {r['stage']} | {r['setting']} | {r['input']} | {r['seed']} | {r['input_events_each']} | {r['P1_8_intact']}→{r['P1_8_blocked']} | {r['P1_49_intact']}→{r['P1_49_blocked']} | {r['mAL_intact']}→{r['mAL_blocked']} |")
lines+=['','All paired inputs match. Three restoration runs exactly reproduce every saved array from discovery intactseed1.','', 'Read EVIDENCE.md for subtype-mapping caveat, the literature basis and scope of sign assumptions, and why a spike response is not behavioral preference.']
(p/'SUMMARY.md').write_text('\n'.join(lines)+'\n')
print(len(rows),'comparisons',len(checks),'exact restorations',len(allrows),'runs')
