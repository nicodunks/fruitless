"""Prespecified route diagnostic: unchanged full LIF, corrected readout, sign sensitivity."""
import sys,json,time
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'model-audit'))
from probe import simulate
root=Path(__file__).resolve().parents[1];out=Path(__file__).parent
nodes=np.load(root/'full-nodes.npz');ids=nodes['ids'];base=nodes['signs'];W=load_npz(root/'full-graph.npz');m=json.loads((root/'full-meta.json').read_text());groups={k:np.array(v,np.int32) for k,v in m['groups'].items()}
groups['vAB3']=np.flatnonzero(np.isin(ids,[11998,13341,13693,512498])).astype(np.int32)
groups['R71G01_related']=np.flatnonzero(np.isin(ids,[12442,16719,17867,20117,20803,23968,519518,522419])).astype(np.int32)
plan={'question':'Does literature-supported excitatory vAB3 routing permit mAL-mediated disinhibition? No behavioral preference decoder.','populations':['candidate_male','candidate_female','vAB3'],'settings':['vAB3_excitatory','vAB3_and_female_input_excitatory'],'seeds':[11,12,13,1],'conditions':['intact','mAL_blocked'],'model':'unchanged run.py LIF, probe.py only instruments voltages','readouts':['R71G01_related','P1_related','mAL','vAB3'],'note':'Third sign setting duplicates directvAB3 pathway only insofar femaleinputs remaininactive; retain all outcomes.'}
(out/'HOLDOUT-PLAN.json').write_text(json.dumps(plan,indent=2))
results=[]
for setting in plan['settings']:
 signs=base.copy()
 if setting!='conservative':signs[groups['vAB3']]=1
 if setting=='vAB3_and_female_input_excitatory':signs[groups['candidate_female']]=1
 for pop in plan['populations']:
  if (setting=='vAB3_and_female_input_excitatory') != (pop=='candidate_female'):continue
  for seed in plan['seeds']:
   for condition in (['restored'] if seed==1 else plan['conditions']):
    mask=np.zeros(len(ids),np.bool_)
    if condition=='mAL_blocked':mask[groups['mAL']]=True
    inp=groups[pop];rate=150. if pop=='vAB3' else 5550/len(inp)
    t=time.perf_counter();a=simulate(W.indptr,W.indices,W.data,signs,inp,rate,mask,seed)
    bins,events,peak,trough,area,exc,inh,gpeak,gtrough=a
    key=f'holdout__{setting}__{pop}__{condition}__{seed}'
    b,i=np.nonzero(bins);np.savez_compressed(out/(key+'.npz'),bin=b.astype(np.uint8),neuron=i.astype(np.int32),count=bins[b,i],peak=peak,trough=trough,area=area,exc=exc,inh=inh)
    row={'key':key,'setting':setting,'input':pop,'condition':condition,'seed':seed,'events':int(events),'total_spikes':int(bins.sum()),'seconds':time.perf_counter()-t,'readouts':{}}
    for k in plan['readouts']:
     g=groups[k];row['readouts'][k]={'spikes':int(bins[:,g].sum()),'mean_hz':float(bins[5:,g].sum()/len(g)/.25),'peak_depolarization_mV':float((peak[g]+52).max()),'mean_voltage_deviation_mV':float(area[g].mean()/.25/1000),'min_voltage_mV':float(trough[g].min()),'net_exc_arrivals':float(exc[g].sum()),'net_inh_arrivals':float(inh[g].sum())}
    results.append(row);print(json.dumps(row),flush=True);(out/'holdout-results.json').write_text(json.dumps({'plan':plan,'results':results},indent=2))
print('DONE',flush=True)
