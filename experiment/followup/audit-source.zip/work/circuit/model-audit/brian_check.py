from brian2 import *
import numpy as np,json
prefs.codegen.target='numpy'
prefs.codegen.loop_invariant_optimisations=False
# Brian2 2.6 wheel targets NumPy1 ABI; use its supported purePython queue with NumPy2.
from brian2.synapses.spikequeue import SpikeQueue
get_device().spike_queue=lambda source_start,source_end: SpikeQueue(source_start=source_start,source_end=source_end)
start_scope();defaultclock.dt=.1*ms
G=NeuronGroup(1,'dv/dt=(v0-v+g)/tm:volt\ndg/dt=-g/ts:volt',method='linear',namespace={'v0':-52*mV,'tm':20*ms,'ts':5*ms});G.v=-52*mV;G.g=20*mV
M=StateMonitor(G,['v','g'],record=True,when='end');Network(G,M).run(20*ms)
t=np.asarray(M.t/ms)+.1;em=np.exp(-t/20);eg=np.exp(-t/5)
err=float(np.max(np.abs(M.v[0]/mV-(-52+20/3*(em-eg)))))
# The reference flags both variables 'unless refractory'; arriving spikes must be discarded during that period.
start_scope();defaultclock.dt=.1*ms
G=NeuronGroup(1,'dv/dt=(v0-v+g)/tm:volt (unless refractory)\ndg/dt=-g/ts:volt (unless refractory)\nrfc:second',threshold='v>-45*mV',reset='v=-52*mV;g=0*mV',refractory='rfc',method='linear',namespace={'v0':-52*mV,'tm':20*ms,'ts':5*ms});G.v=-44*mV;G.g=0*mV;G.rfc=2.2*ms
S=SpikeGeneratorGroup(1,[0,0],[.5,3]*ms);syn=Synapses(S,G,on_pre='g+=20*mV');syn.connect()
M=StateMonitor(G,['v','g'],record=True,when='end');Network(G,S,syn,M).run(5*ms)
report={'brian2_version':__import__('brian2').__version__,'exact_linear_update_max_abs_error_mv':err,'arrival_at_0_5ms_during_refractory_g_mv':float(M.g[0][5]/mV),'arrival_at_3ms_after_refractory_g_mv':float(M.g[0][30]/mV),'scope':'Validates homogeneous linear integration and refractory arrival suppression only, not full network equivalence. Standard Brian synapses run after threshold, whereas local ringbuffer integrates received synapses before threshold; at least one timestep scheduling difference remains.'}
print(json.dumps(report,indent=2));open('work/circuit/model-audit/brian_check.json','w').write(json.dumps(report,indent=2))
assert err<1e-10 and report['arrival_at_0_5ms_during_refractory_g_mv']==0 and report['arrival_at_3ms_after_refractory_g_mv']==20
