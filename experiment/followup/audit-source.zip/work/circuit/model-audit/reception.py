from probe import simulate
from scipy.sparse import load_npz
import numpy as np,json,time,hashlib
from pathlib import Path
root=Path('work/circuit');m=json.loads((root/'full-meta.json').read_text());groups={k:np.array(v,np.int32) for k,v in m['groups'].items()};a=np.load(root/'full-nodes.npz');W=load_npz(root/'full-graph.npz');report=[];groups['P1_corrected']=np.flatnonzero(np.isin(a['ids'],[12442,16719,17867,20117,20803,23968,519518,522419])).astype(np.int32)
for setting in ['conservative','female_input_excitatory']:
 signs=a['signs'].copy()
 if setting=='female_input_excitatory':signs[groups['candidate_female']]=1
 for pop in ['candidate_male','candidate_female']+(['PPN1'] if setting=='conservative' else []):
  for seed in [1,2,3]:
   t=time.time();bins,events,peak,trough,area,exc,inh,gpeak,gtrough=simulate(W.indptr,W.indices,W.data,signs,groups[pop],150 if pop=='PPN1' else 5550/len(groups[pop]),np.zeros(len(a['ids']),np.bool_),seed)
   r={'setting':setting,'input':pop,'seed':seed,'seconds':time.time()-t,'events':events,'spikes':int(bins.sum())}
   for group in ['mAL','P1_related','P1_corrected','PPN1']:
    g=groups[group];p=peak[g];q=trough[g]
    r[group]={'max_depolarization_mv':float(p.max()+52),'mean_peak_depolarization_mv':float(p.mean()+52),'max_hyperpolarization_mv':float(-52-q.min()),'neurons_depolarized':int((p>-51.999).sum()),'mean_voltage_area_mv_ms':float(area[g].mean()),'mean_voltage_mv':float(-52+area[g].mean()/250),'mean_net_positive_arrivals_mv':float(exc[g].mean()),'mean_net_negative_arrivals_mv':float(inh[g].mean()),'max_g_mv':float(gpeak[g].max()),'min_g_mv':float(gtrough[g].min()),'spikes':int(bins[:,g].sum())}
   oldpath=root/f'{setting}__{pop}__intact__{seed}.npz'
   if oldpath.exists():
    old=np.load(oldpath);b,i=np.nonzero(bins);r['original_recording_exact']=bool(np.array_equal(b,old['bin']) and np.array_equal(i,old['neuron']) and np.array_equal(bins[b,i],old['count']));assert r['original_recording_exact']
   report.append(r);print(json.dumps(r),flush=True)
(root/'model-audit/reception.json').write_text(json.dumps({'note':'Voltage measured after subthreshold step, before external impulses; arrivals are net signed arrival per step, not separately recorded excitatory/inhibitory synapses. 50–300ms measurement; fullnetwork original dynamics unchanged.','probe_sha256':hashlib.sha256((root/'model-audit/probe.py').read_bytes()).hexdigest(),'results':report},indent=2))
