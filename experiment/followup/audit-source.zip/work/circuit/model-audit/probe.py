"""Small full-network LIF experiment. See PROTOCOL.md; no fitted behavior decoder."""
import argparse, json, time, hashlib
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz
from numba import njit

@njit(cache=True)
def simulate(indptr, targets, weights, signs, inputs, input_hz, blocked, seed, duration=300., dt=.1):
    n=len(signs); steps=int(round(duration/dt)); delay=int(round(1.8/dt)); refractory=int(round(2.2/dt))
    v=np.full(n,-52.); g=np.zeros(n); release=np.zeros(n,np.int32)
    pending=np.zeros((delay+1,n)); bins=np.zeros((int(np.ceil(duration/10)),n),np.int32)
    driven=np.zeros(n,np.bool_); driven[inputs]=True
    np.random.seed(seed)
    # Exact solution of the two linear ODEs during each non-refractory step.
    em=np.exp(-dt/20); eg=np.exp(-dt/5); coupling=5/15*(em-eg)
    peak=np.full(n,-52.); trough=np.full(n,-52.); area=np.zeros(n); exc=np.zeros(n); inh=np.zeros(n); gpeak=np.zeros(n); gtrough=np.zeros(n); event_count=0
    for step in range(steps):
        t=step*dt; slot=step%(delay+1)
        for i in range(n):
            incoming=pending[slot,i];pending[slot,i]=0
            if step>=release[i]:
                if t>=50:
                    exc[i]+=max(incoming,0);inh[i]+=min(incoming,0)
                g[i]+=incoming
                v[i]=-52+(v[i]+52)*em+g[i]*coupling
                g[i]*=eg
            if t>=50:
                peak[i]=max(peak[i],v[i]);trough[i]=min(trough[i],v[i]);area[i]+=(v[i]+52)*dt
                gpeak[i]=max(gpeak[i],g[i]);gtrough[i]=min(gtrough[i],g[i])
        if 50<=t<250:
            for i in inputs:
                if np.random.random()<input_hz*dt/1000:
                    v[i]+=68.75;event_count+=1
        for i in range(n):
            if step>=release[i] and v[i]>-45:
                bins[min(int(t/10),bins.shape[0]-1),i]+=1
                v[i]=-52;g[i]=0;release[i]=step+(0 if driven[i] else refractory)
                if not blocked[i] and signs[i]!=0:
                    dest=(step+delay)%(delay+1)
                    for e in range(indptr[i],indptr[i+1]):
                        pending[dest,targets[e]]+=weights[e]*.275*signs[i]
    return bins,event_count,peak,trough,area,exc,inh,gpeak,gtrough

