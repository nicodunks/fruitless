from pathlib import Path
s=Path('outputs/fruitless/experiment/run.py').read_text().split('def main():')[0]
s=s.replace('    event_count=0','    peak=np.full(n,-52.); trough=np.full(n,-52.); area=np.zeros(n); exc=np.zeros(n); inh=np.zeros(n); gpeak=np.zeros(n); gtrough=np.zeros(n); event_count=0')
s=s.replace('                g[i]+=incoming','                if t>=50:\n                    exc[i]+=max(incoming,0);inh[i]+=min(incoming,0)\n                g[i]+=incoming')
s=s.replace('        if 50<=t<250:', '            if t>=50:\n                peak[i]=max(peak[i],v[i]);trough[i]=min(trough[i],v[i]);area[i]+=(v[i]+52)*dt\n                gpeak[i]=max(gpeak[i],g[i]);gtrough[i]=min(gtrough[i],g[i])\n        if 50<=t<250:')
s=s.replace('    return bins,event_count','    return bins,event_count,peak,trough,area,exc,inh,gpeak,gtrough')
Path('work/circuit/model-audit/probe.py').write_text(s)
