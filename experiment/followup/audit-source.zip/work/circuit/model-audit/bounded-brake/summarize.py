from pathlib import Path
import json
import numpy as np
p=Path(__file__).parent;r=json.loads((p/'results.json').read_text());rows=r['results'];summary=[]
for ei in [-70.,-80.]:
 for condition in ['tonic_only','mAL_activated','all_mAL_output_blocked','direct_mAL_P1_blocked']:
  s=[x for x in rows if x['inhibitory_reversal_mV']==ei and x['condition']==condition]
  summary.append({'reversal_mV':ei,'condition':condition,'P1_rates_Hz':[x['primary_Hz'] for x in s],'mean_P1_Hz':float(np.mean([x['primary_Hz'] for x in s])),'min_voltage_mV':min(x['voltage_min_mV'] for x in s),'actual_mAL_rate_range_Hz':[min(x['mAL_Hz'] for x in s),max(x['mAL_Hz'] for x in s)]})
(p/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
