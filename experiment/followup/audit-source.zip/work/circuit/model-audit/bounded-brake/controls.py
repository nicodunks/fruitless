from run import run
import numpy as np,json,time
from scipy.sparse import load_npz
from pathlib import Path
root=Path('work/circuit');out=Path(__file__).parent;data=np.load(root/'full-nodes.npz');ids=data['ids'];W=load_npz(root/'full-graph.npz');meta=json.loads((root/'full-meta.json').read_text());p1=np.searchsorted(ids,[12442,16719,17867,20117,20803,23968,519518,522419]);mal=np.array(meta['groups']['mAL'],np.int32)
events=np.random.default_rng(1).random((7000,len(mal)))<.015;events[:1000]=False;events[6000:]=False;rows=[]
for ei in [-70.,-80.]:
 for condition in [0,1]:
  begin=time.time();b,vmin,vmax=run(W.indptr,W.indices,W.data,data['signs'],p1,mal,events,0.,condition,ei)
  r={'inhibitory_reversal_mV':ei,'condition':'no_input' if condition==0 else 'mAL_only','drive_mV':0.,'seed':1,'primary_Hz':float(b[10:60,p1].sum()/4),'mAL_Hz':float(b[10:60,mal].sum()/len(mal)/.5),'network_spikes':int(b.sum()),'voltage_min_mV':vmin,'voltage_max_before_external_mV':vmax,'seconds':time.time()-begin}
  if condition==0:assert not b.any()
  assert vmin>=ei-1e-8
  rows.append(r);print(json.dumps(r),flush=True)
(out/'controls.json').write_text(json.dumps(rows,indent=2))
