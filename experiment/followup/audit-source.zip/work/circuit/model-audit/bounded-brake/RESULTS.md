# Bounded inhibitory conductance sensitivity

Completed all40 fixed-grid trials in364.49seconds, plus four zero-tonic controls. The full166606-neuron graph and25574615edges were included throughout. No frontend changes.

P1 rates below are population means over the500ms tonic-drive window. Each row uses the same five seeds1–5; the two reversal potentials reuse those seeds and are model sensitivities, not independent biological samples.

| Inhibitory reversal | Tonic only | mAL activated | All mAL output blocked | Direct mAL→P1 edges blocked |
|---|---:|---:|---:|---:|
| −70mV |32.75Hz|0Hz|32.75Hz|38.65Hz mean(range38–40.75)|
| −80mV |33.75Hz|0Hz|33.75Hz|39.75Hz mean(range38–40.75)|

All five seeds at each reversal show complete P1 spike suppression during mAL activation and recovery after blocking mAL output. Direct-edge block also recovers P1 activity; its rate can exceed tonic-only because other mAL network effects remain. Actual externally driven mAL population rates range146.27–149.95Hz. No-input controls have zero network spikes; mAL-only controls have zero P1 spikes. Every voltage bound assertion passes: global minimum across40trials is−77.838mV, safely above the corresponding−80mV reversal; at−70mV the lowest value is−69.109mV.

This reproduces an encoded anatomical inhibitory gate in a synthetic coactivation assay without the implausible negative voltages of the unbounded current model. P1 was given artificial tonic excitation; this is not a sensory, mate-choice, sexual-preference, or behavioral experiment. Inhibitory reversal and conductance kinetics are assumed sensitivity parameters, not measured receptor-specific fits.

`results.json` retains all40trials, code/protocol hashes, actual mAL rates, neuron recruitment and voltage extrema. `controls.json` retains all four zero-tonic controls. `summary.json` gives the complete five-seed rates. Eight seed1 spike recordings(one per condition/reversal) are preserved as sparse NPZ files.

Independent review of the parent's `bounded_routes.py` and its36recorded trials also passed input-schedule matching, body-ID resolution and voltage bounds. That separate assay has no tonic P1 drive; only outgoing mAL transmission changes between paired runs. Its three fresh seeds11–13 yield male-candidate P1 spikes0→4/5/1 at−70mV and0→4/7/1 at−80mV. Female-candidate responses remain larger. This supports a conditional modeled response to the candidate male pathway; it does not demonstrate preference. The result depends on explicitly overriding vAB3 and candidate-female transmitter signs to excitatory. Three seeds reused across two reversal settings are not six independent seeds.
