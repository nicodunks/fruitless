import json,time,hashlib
from pathlib import Path
import numpy as np
from scipy.sparse import load_npz
from numba import njit

@njit(cache=True)
def run(indptr,dest,weights,signs,p1,mal,events,tonic,condition,ei,dt=.1):
 n=len(signs);steps=events.shape[0];delay=int(round(1.8/dt));ref=int(round(2.2/dt))
 v=np.full(n,-52.);ge=np.zeros(n);hi=np.zeros(n);release=np.zeros(n,np.int32)
 pending_e=np.zeros((delay+1,n));pending_i=np.zeros((delay+1,n))
 p1mask=np.zeros(n,np.bool_);p1mask[p1]=True;malmask=np.zeros(n,np.bool_);malmask[mal]=True
 counts=np.zeros((int(np.ceil(steps*dt/10)),n),np.int32);eg=np.exp(-dt/5);vmin=-52.;vmax=-52.
 for step in range(steps):
  t=step*dt;slot=step%(delay+1);drive=tonic if 100<=t<600 else 0.
  for i in range(n):
   inc_e=pending_e[slot,i];inc_i=pending_i[slot,i];pending_e[slot,i]=0;pending_i[slot,i]=0
   if step>=release[i]:
    ge[i]+=inc_e;hi[i]+=inc_i
    rate=(1+hi[i])/20;decay=np.exp(-rate*dt)
    equilibrium=(-52+hi[i]*ei+(drive if p1mask[i] else 0))/(1+hi[i])
    coupling=(eg-decay)/(20*(rate-.2)) if abs(rate-.2)>1e-10 else dt*decay/20
    v[i]=equilibrium+(v[i]-equilibrium)*decay+ge[i]*coupling
    ge[i]*=eg;hi[i]*=eg
   vmin=min(vmin,v[i]);vmax=max(vmax,v[i])
  if condition!=0:
   for j in range(len(mal)):
    if events[step,j]:v[mal[j]]+=68.75
  for i in range(n):
   if step>=release[i] and v[i]>-45:
    counts[int(t/10),i]+=1;v[i]=-52;ge[i]=0;hi[i]=0;release[i]=step+(0 if malmask[i] and condition!=0 else ref)
    if signs[i]==0 or (condition==2 and malmask[i]):continue
    slot2=(step+delay)%(delay+1)
    for e in range(indptr[i],indptr[i+1]):
     target=dest[e]
     if condition==3 and malmask[i] and p1mask[target]:continue
     if signs[i]>0:pending_e[slot2,target]+=weights[e]*.275
     else:pending_i[slot2,target]+=weights[e]*.275/(-52-ei)
 return counts,vmin,vmax

def main():
 root=Path('work/circuit');out=Path(__file__).parent;meta=json.loads((root/'full-meta.json').read_text());data=np.load(root/'full-nodes.npz');ids=data['ids'];signs=data['signs'];W=load_npz(root/'full-graph.npz')
 p1ids=np.array([12442,16719,17867,20117,20803,23968,519518,522419]);p1=np.searchsorted(ids,p1ids);assert np.array_equal(ids[p1],p1ids)
 mal=np.array(meta['groups']['mAL'],np.int32);names=['tonic_only','mAL_activated','all_mAL_output_blocked','direct_mAL_P1_blocked'];rows=[];started=time.perf_counter()
 for ei in [-70.,-80.]:
  for seed in range(1,6):
   events=np.random.default_rng(seed).random((7000,len(mal)))<.015;events[:1000]=False;events[6000:]=False;digest=hashlib.sha256(events.tobytes()).hexdigest()
   for condition,name in enumerate(names):
    begin=time.perf_counter();counts,vmin,vmax=run(W.indptr,W.indices,W.data,signs,p1,mal,events,10.,condition,ei)
    assert vmin>=ei-1e-8
    row={'inhibitory_reversal_mV':ei,'drive_mV':10.,'seed':seed,'condition':name,'external_schedule_sha256':digest,'primary_Hz':float(counts[10:60,p1].sum()/8/.5),'primary_active':int(np.any(counts[10:60,p1],axis=0).sum()),'mAL_Hz':float(counts[10:60,mal].sum()/len(mal)/.5),'network_spikes':int(counts.sum()),'active_neurons':int(np.any(counts,axis=0).sum()),'voltage_min_mV':vmin,'voltage_max_before_external_mV':vmax,'seconds':time.perf_counter()-begin};rows.append(row);print(json.dumps(row),flush=True)
    if seed==1:
     b,i=np.nonzero(counts);np.savez_compressed(out/f'bounded_{int(ei)}_{name}.npz',bin=b.astype(np.uint8),neuron=i.astype(np.int32),count=counts[b,i])
 report={'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((out/'PROTOCOL.md').read_bytes()).hexdigest(),'neurons':len(ids),'edges':W.nnz,'primary_body_ids':p1ids.tolist(),'results':rows,'seconds':time.perf_counter()-started,'checks':{'voltage_bound_all_trials':True}}
 (out/'results.json').write_text(json.dumps(report,indent=2));print('COMPLETE',report['seconds'],flush=True)
if __name__=='__main__':main()
