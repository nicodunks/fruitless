# Independent simulator audit and subthreshold reception check

The original full-network simulation was left unchanged. `probe.py` copies its equations and adds voltage/current summaries; it does not alter network parameters, initial conditions, stimulation, signs, or transmission. `reception.py` runs 15 intact trials: both candidate populations × three seeds × both original sign assumptions, plus three PPN1 trials. All 13 trials for which original recordings exist reproduce their binned spikes exactly. The two additional PPN1 seeds are additional exploratory trials.

## Implementation checks

The exact linear update is correct for dv/dt = (Vrest − v + g)/20ms and dg/dt = −g/5ms. Independent Brian2 comparison gives maximum absolute voltage error 1.918e−13mV. Brian2 also confirms that synaptic arrivals are discarded when both variables carry the `unless refractory` flag. `brian_check.py` uses Brian2's Python spike queue and disables its algebraic loop optimizer to accommodate installed Brian2 2.6 / NumPy2 compatibility; no simulator changes were made. This is a check of the local equations and refractory semantics, not full-network equivalence. Brian's standard event scheduling and local pre-threshold delivery differ by approximately one 0.1ms step.

The physiological/model constants match the local Shiu reference. The trial design does not: reference default duration is1000ms versus the pilot's200ms stimulation. Zero activity initially and absent background/neuromodulation mean inhibition cannot itself create activity unless an excitatory route is already active.

## Structural observations

Candidate sensory neurons have no direct connections to mAL or either broad P1-related readout via the original group selection. PPN1 has only33 synapses across13 edges to mAL (largestedge11) and one synapse to the original broad P1-related group. Therefore PPN1 was a biological pathway check, not a guaranteed positive control under homogeneous synapse weights.

## Recorded reception

Spike silence does not mean no signal arrived. Under the original male-candidate input, the broad49-cell readout shows some depolarization (seed1 maximum2.407mV, nine cells), while inhibitory current dominates other cells. The corrected P1_4a/b eight-cell readout, independently identified by biology audit from v0.9→v1.0 annotations, remains silent in all15runs.

| Input/sign assumption | CorrectedP1 mean membrane voltage over50–300ms, seeds1/2/3 | CorrectedP1 spikes |
|---|---|---|
| Male candidate, either setting | −54.186, −53.775, −53.713mV |0/0/0|
| Female candidate, conservative | −52, −52, −52mV |0/0/0|
| Female candidate, excitatory override | −52.325, −52.344, −52.339mV |0/0/0|
| PPN1, conservative | −53.897, −53.682, −53.155mV |0/0/0|

Rest is−52mV; threshold is−45mV. These results indicate predominantly inhibitory modeled reception, not courtship activation or preference. Per-neuron maximum excursions, group-integrated voltage, net positive/negative arrival sums, and current-state maxima/minima are in`reception.json`.

A large limitation is unbounded current-based hyperpolarization: male-candidate stimulation pushes some mAL neurons~97mV below rest and PPN1~181mV below rest. These extreme values should not be presented as quantitatively physiological. The simulator has no inhibitory reversal potential or conductance saturation. This is a model limitation; changing it would define a new model, not repair a numerical mistake.

## Bounded next tests, not outcome selection

1. Correct readout identity before interpreting courtship. Preserve the original result and identify corrected readout as a post-audit correction.
2. Establish a mechanism-positive-control with weak sustained excitatory drive to P1 plus fixed mAL stimulation, compared with identicaldrive and mAL output block. Report any tonic drive as artificial. Existing68.75mV P1 impulses force spikes and largely bypass the brake; they are not a useful low-threshold assay.
3. Run independently identified upstream routes under literature-justified transmitter alternatives, reporting every setting and seed. Do not select the sign setting because it produces a desired male outcome.
4. A prespecified1000ms stimulation check can assess the short pilot duration, but longer stimulation will not automatically overcome weak connections or incorrect input mappings.
5. A future conductance-based implementation could constrain inhibitory voltage, but this needs a separately specified model and validation; it should not be silently substituted until a preference result appears.

Sources checked: local`reference_model.py`; Brian refractory documentation https://brian2.readthedocs.io/en/stable/user/refractoriness.html . ExactP1 identity is supplied by separate biology audit and should retain its primary annotation mapping evidence in the combined report.
