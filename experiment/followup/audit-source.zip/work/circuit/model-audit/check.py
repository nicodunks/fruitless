from probe import simulate
from scipy.sparse import load_npz
import numpy as np,json,time
from pathlib import Path
root=Path('work/circuit');m=json.loads((root/'full-meta.json').read_text());g={k:np.array(v,np.int32) for k,v in m['groups'].items()};a=np.load(root/'full-nodes.npz');W=load_npz(root/'full-graph.npz');report=[]
for pop in ['candidate_male','candidate_female','PPN1']:
 t=time.time();bins,events,peak,trough=simulate(W.indptr,W.indices,W.data,a['signs'],g[pop],150 if pop=='PPN1' else 5550/len(g[pop]),np.zeros(len(a['ids']),np.bool_),1)
 r={'input':pop,'seconds':time.time()-t,'events':events}
 for group in ['mAL','P1_related']:
  p=peak[g[group]];q=trough[g[group]]
  r[group]={'max_depolarization_mv':float(p.max()+52),'mean_peak_depolarization_mv':float(p.mean()+52),'max_hyperpolarization_mv':float(-52-q.min()),'neurons_depolarized':int((p>-51.999).sum()),'spikes':int(bins[:,g[group]].sum())}
 report.append(r);print(r,flush=True)
(root/'model-audit/subthreshold.json').write_text(json.dumps(report,indent=2))
